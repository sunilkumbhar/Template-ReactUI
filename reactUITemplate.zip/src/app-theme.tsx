import { createMuiTheme } from "@material-ui/core/styles";
import { PRIMARY_COLOR } from "./constants/color";

const theme = createMuiTheme({
  overrides: {
    MuiAppBar: {
      root: {
        background: `${PRIMARY_COLOR} !important`,
      },
    },
    MuiButton: {
      containedPrimary: {
        background: `${PRIMARY_COLOR} !important`,
      },
    },
  },
});
export default theme;
