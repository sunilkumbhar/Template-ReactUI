import axios from "axios";
import {
  BASE_PATH,
  // APP_NAME,
  // AUTH_TOKEN
} from "../constants/api";

const api = axios.create({
  baseURL: BASE_PATH,
  timeout: 30000,
  headers: { "Content-Type": "application/json" },
});

// api.interceptors.request.use(
//   config => {
//     config.headers.AppName = APP_NAME;
//     config.headers.AuthenticationToken = AUTH_TOKEN;

//     return config;
//   },
//   err => Promise.reject(err)
// );

export default api;
