import { MuiThemeProvider } from "@material-ui/core/styles";
import { ConnectedRouter } from "connected-react-router";
import * as React from "react";
import { Provider } from "react-redux";
import theme from "./app-theme";
import { configStore, history } from "./store/config";
import MainHomeComponent from "./components/main-home";
import "./styles/index.css";

const store = configStore();

function App() {
  return (
    <MuiThemeProvider theme={theme}>
      <Provider store={store}>
        <ConnectedRouter history={history}>
          <MainHomeComponent />
        </ConnectedRouter>
      </Provider>
    </MuiThemeProvider>
  );
}

export default App;
