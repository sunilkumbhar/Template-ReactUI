import styled from "styled-components";

export const GridTableWrapper = styled.div`
  padding: 10px 0;
`;
