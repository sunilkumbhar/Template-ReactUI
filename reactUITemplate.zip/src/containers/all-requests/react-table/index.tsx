import React, { useEffect, useState } from "react";
import MaterialTable from "material-table";
import { FullWidthContainer } from "../../../styles/common";

function MaterialTableGrid(props: any) {
  const { gridData, showFilter } = props;
  const [tableData, setTableData] = useState([]);
  useEffect(() => {
    const newGridData = JSON.parse(JSON.stringify(gridData));
    setTableData(newGridData);
  }, [gridData]);

  const columns = React.useMemo(
    () => [
      {
        Header: "User Id",
        accessor: "userId", // accessor is the "key" in the data
      },
      {
        Header: "Title",
        accessor: "title",
      },
      {
        Header: "Description",
        accessor: "body",
      },
    ],
    []
  );

  const tableInstance = useTable({ columns, data });
  return (
    <FullWidthContainer>
      <MaterialTable
        columns={[
          {
            field: "userId",
            title: "User Id",
          },
          {
            field: "title",
            title: "Title",
          },
          {
            field: "body",
            title: "Description",
          },
        ]}
        data={tableData}
        title="All Request Data"
        style={{
          minWidth: "650px",
          overflow: "auto",
        }}
        options={{
          filtering: showFilter,
          pageSizeOptions: [10, 20, 50],
          pageSize: 10,
        }}
      />
    </FullWidthContainer>
  );
}

export default MaterialTableGrid;
