import { createSlice, createAction } from "@reduxjs/toolkit";

// Define Actions
export const actAllRequestsFetchData = createAction("ALL_REQUESTS_FETCH_DATA");

// Define Reducers
const initialState = {
  postData: [],
  emailId: "",
  name: "",
  roleId: "",
};

const allRequestsSlice = createSlice({
  name: "allRequests",
  initialState,
  reducers: {
    setAllRequestData: (state: any, action: any) => {
      state.postData = action.payload;
    },
    setUserDetails: (state: any, action: any) => {
      state.emailId = action.payload.emailId;
      state.name = action.payload.name;
      state.roleId = action.payload.roleId;
    },
  },
});

export const { setAllRequestData, setUserDetails } = allRequestsSlice.actions;
export const allRequestsReducer = allRequestsSlice.reducer;
