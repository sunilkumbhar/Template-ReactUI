import { all, call, put, takeLatest } from "redux-saga/effects";
import { fetchData } from "./api";
import { setAllRequestData, actAllRequestsFetchData } from "./slice";

function* watchGetData() {
  yield takeLatest(actAllRequestsFetchData, getData);
}

function* getData(action: any) {
  try {
    const response = yield call(fetchData);
    const responseData = response.data;
    yield put(setAllRequestData(responseData));
  } catch (err) {
    console.log(err);
  }
}

export default function* allRequestSaga() {
  yield all([watchGetData()]);
}
