export const GET_POSTS: string = `/posts`;
