import api from "../../utils/api";
import { GET_POSTS } from "./constants";

/**
 * Function for getting some data
 */
export const fetchData = async () => {
  const response = await api.get(`${GET_POSTS}`);
  return response;
};
