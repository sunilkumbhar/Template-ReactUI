import React, { useEffect } from "react";
import Card from "@material-ui/core/Card";
import CardContent from "@material-ui/core/CardContent";
import Typography from "@material-ui/core/Typography";
import { useDispatch } from "react-redux";
// import { actionSetPageTitle } from "../../store/common/actions";
import { setPageTitle } from "../../store/common/slice";
import { PageWrapper } from "../../styles/common";
import "./index.css";

function AboutUs(props: any) {
  const dispatch = useDispatch();
  const title = "About Project Name";

  useEffect(() => {
    dispatch(setPageTitle(title));
  }, [dispatch]);

  return (
    <PageWrapper>
      <div className="home-wrapper">
        <Card>
          <CardContent>
            <Typography variant="h4" component="h2">
              Project Title Will come here
            </Typography>
            <Typography component="p">
              Project description will come here
            </Typography>
            <Typography className="version" color="textSecondary">
              ver 0.1
            </Typography>
          </CardContent>
        </Card>
      </div>
    </PageWrapper>
  );
}

export default AboutUs;
