import React from "react";
import Typography from "@material-ui/core/Typography";
import Divider from "@material-ui/core/Divider";
import Avatar from "@material-ui/core/Avatar";
import Card from "@material-ui/core/Card";
import ExitToApp from "@material-ui/icons/ExitToApp";
import Grid from "@material-ui/core/Grid";

function UserDropdown(props: any) {
  const { loggedInUser } = props;

  return (
    <Card className="userdropdown">
      <div className="title-container">
        <Typography variant="h5">My Account</Typography>
      </div>
      <Divider />
      <Grid container={true} direction="row" className="py-10">
        <Grid item={true} xs={3} className="avatar-parent">
          <Avatar className="bigAvatar">
            {loggedInUser.name.substring(0, 1).toUpperCase()}
          </Avatar>
        </Grid>
        <Grid item={true} xs={9}>
          <Typography
            variant="h5"
            component="h5"
            color="inherit"
            style={{ textTransform: "capitalize" }}
          >
            {loggedInUser.name}
          </Typography>
          <Typography
            color="inherit"
            style={{ wordBreak: "break-all" }}
          >{`(${loggedInUser.email})`}</Typography>
          <Typography color="inherit" className="mt-5">
            {loggedInUser.roleName}
          </Typography>
        </Grid>
      </Grid>
      <Divider />
      <Grid container={true} direction="row" className="signout-container">
        <Grid item={true} xs={3} className="avatar-parent">
          <ExitToApp />
        </Grid>
        <Grid item={true} xs={9} className="signout-label">
          <Typography color="inherit" className="signout">
            Sign out
          </Typography>
        </Grid>
      </Grid>
    </Card>
  );
}

export default UserDropdown;
