import React, { useState } from "react";
import IconButton from "@material-ui/core/IconButton";
import Avatar from "@material-ui/core/Avatar";
import UserDropdown from "./user-dropdown";

function Account(props: any) {
  const { loggedInUser } = props;
  const [showUserDropdown, setUserDropdownVisibility] = useState(false);

  const iconButtonClick = () => {
    setUserDropdownVisibility(!showUserDropdown);
  };
  return (
    <div>
      <IconButton color="inherit" onClick={iconButtonClick}>
        <Avatar style={{ fontSize: 30 }}>
          {loggedInUser.name.substring(0, 1).toUpperCase()}
        </Avatar>
      </IconButton>
      {showUserDropdown ? <UserDropdown loggedInUser={loggedInUser} /> : null}
    </div>
  );
}

export default Account;
