import React, { useState } from "react";

import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import Grid from "@material-ui/core/Grid";
import IconButton from "@material-ui/core/IconButton";
import MenuIcon from "@material-ui/icons/Menu";
import Button from "@material-ui/core/Button";
import logo from "../../styles/images/uniceflogo.png";
import DrawerComponent from "./drawer";
import Typography from "@material-ui/core/Typography";
import Account from "./account";
import { useSelector } from "react-redux";
import "./index.css";

function HeaderComponent(props: any) {
  const [isDrawerVisible, setDrawerVisibility] = useState(false);
  const [auth, setAuth] = useState(true);

  const loggedInUser = {
    name: "Ammar Tinwala",
    email: "atinwala@unicef.org",
    roleName: "Web Developer",
  };

  const pageTitle = useSelector((state: any) => state.common.pageTitle);

  const toggleDrawer = () => {
    setDrawerVisibility(!isDrawerVisible);
  };

  const logout = () => {
    localStorage.clear();
    setAuth(false);
    // Logout logic will go over here
  };

  const login = () => {
    setAuth(true);
    // Login logic will go over here
  };

  return (
    <React.Fragment>
      <DrawerComponent
        visible={isDrawerVisible}
        setVisibility={setDrawerVisibility}
      />
      <div>
        <AppBar position="relative">
          <Toolbar>
            <IconButton
              color="inherit"
              aria-label="Menu"
              onClick={toggleDrawer}
              disabled={auth ? false : true}
            >
              <MenuIcon />
            </IconButton>
            <Grid
              container={true}
              direction="row"
              justify="space-between"
              alignItems="center"
            >
              <Grid item={true}>
                <Typography variant="h5" color="inherit">
                  {pageTitle}
                </Typography>
              </Grid>
              <Grid item={true}>
                <img src={logo} alt="Unicef Logo" />
              </Grid>
              <Grid item={true}>
                {auth ? (
                  <Account loggedInUser={loggedInUser} logout={logout} />
                ) : (
                  <Button color="inherit" onClick={login}>
                    Login
                  </Button>
                )}
              </Grid>
            </Grid>
          </Toolbar>
        </AppBar>
      </div>
    </React.Fragment>
  );
}

export default HeaderComponent;
