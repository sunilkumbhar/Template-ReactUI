import React from "react";
import Drawer from "@material-ui/core/Drawer";
import Divider from "@material-ui/core/Divider";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemText from "@material-ui/core/ListItemText";
import Typography from "@material-ui/core/Typography";
import { HOME_PATH, ALL_REQUESTS, NEW_REQUEST } from "../../../constants/api";
import { history } from "../../../store/config";

function DrawerComponent(props: any) {
  const { setVisibility, visible } = props;

  const closeDrawer = () => {
    setVisibility(false);
  };
  const goToPath = (path: any) => (event: any) => {
    history.push(path);
  };

  return (
    <Drawer open={visible} onClose={closeDrawer}>
      <div
        className="drawer-container"
        tabIndex={0}
        role="button"
        onClick={closeDrawer}
        onKeyDown={closeDrawer}
      >
        <List>
          <ListItem button={false}>
            <Typography variant="h5" color="inherit" noWrap={true}>
              CPH React Template
            </Typography>
          </ListItem>
          <Divider />
          <ListItem button={true} onClick={goToPath(ALL_REQUESTS)}>
            <ListItemText primary="All Requests" />
          </ListItem>
          <ListItem button={true} onClick={goToPath(NEW_REQUEST)}>
            <ListItemText primary="New Request" />
          </ListItem>
          <ListItem button={true} onClick={goToPath(HOME_PATH)}>
            <ListItemText primary="About PROJECT" />
          </ListItem>
        </List>
      </div>
    </Drawer>
  );
}

export default DrawerComponent;
