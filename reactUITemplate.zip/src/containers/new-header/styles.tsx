import styled from "styled-components";
import { PRIMARY_COLOR } from "../../constants/color";
import AppBar from "@material-ui/core/AppBar";

export const VerticalLine = styled.div`
  && {
    width: 1px;
    height: 35px;
    background-color: #fff;
  }
`;

export const MenuContainer = styled.div`
  && {
    width: 100%;
    padding: 0 10px;
    position: relative;
    margin: 0 auto;

    @media (min-width: 1024px) {
      max-width: 960px;
    }

    @media (min-width: 1440px) {
      max-width: 1200px;
    }
  }
`;

export const UHeader = styled(AppBar)`
  && {
    background-color: ${PRIMARY_COLOR} !important;
    height: 60px;
  }
`;
