import React, { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import Avatar from "@material-ui/core/Avatar";
import UserDropdown from "./user-dropdown";
import { Grid } from "@material-ui/core";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import OutsideAlerter from "./click-outside";
import { setUserDropdownShow } from "./slice";

function Account(props: any) {
  const { loggedInUser, logout } = props;
  const dispatch = useDispatch();
  const [showUserDropdownVisibility, setUserDropdownVisibility] = useState(
    false
  );
  const isUserDropDownShow = useSelector(
    (state: any) => state.newHeader.isUserDropDownShow
  );
  useEffect(() => {
    if (!isUserDropDownShow) {
      setUserDropdownVisibility(false);
    } else {
      setUserDropdownVisibility(true);
    }
  }, [isUserDropDownShow]);

  const iconButtonClick = () => {
    dispatch(setUserDropdownShow(showUserDropdownVisibility));
  };
  return (
    <Grid container={true} justify="flex-end">
      <Grid item={true}>
        <Typography
          component="div"
          className="user-name-block"
          onClick={iconButtonClick}
        >
          <Grid container={true} spacing={2} alignItems="center">
            <Grid item={true}>
              <Avatar>
                {loggedInUser.name.substring(0, 1).toUpperCase()}
                {loggedInUser.lastName
                  ? loggedInUser.lastName.substring(0, 1).toUpperCase()
                  : ""}
              </Avatar>
            </Grid>
            <Grid item={true}>
              <Typography component="span" className="un-username">
                {loggedInUser.name}{" "}
                {loggedInUser.lastName ? loggedInUser.lastName : ""}
              </Typography>
            </Grid>
            <Grid item={true} style={{ paddingLeft: 0, paddingTop: "15px" }}>
              <ExpandMoreIcon />
            </Grid>
          </Grid>
        </Typography>

        {showUserDropdownVisibility ? (
          <OutsideAlerter>
            <UserDropdown loggedInUser={loggedInUser} logout={logout} />
          </OutsideAlerter>
        ) : null}
      </Grid>
    </Grid>
  );
}

export default Account;
