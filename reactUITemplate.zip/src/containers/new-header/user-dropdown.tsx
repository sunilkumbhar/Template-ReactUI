import React from "react";
import Typography from "@material-ui/core/Typography";
import Divider from "@material-ui/core/Divider";
import Avatar from "@material-ui/core/Avatar";
import Grid from "@material-ui/core/Grid";

function UserDropdown(props: any) {
  const { loggedInUser, logout } = props;
  const logoutUser = () => {
    logout();
  };

  return (
    <Typography component="div" className="dd-container">
      <Grid container={true} direction="row" className="py-16">
        <Grid item={true} xs={3}>
          <Typography component="div" className="text-center">
            <Avatar className="dd-big-avatar">
              {loggedInUser.name.substring(0, 1).toUpperCase()}
              {loggedInUser.lastName
                ? loggedInUser.lastName.substring(0, 1).toUpperCase()
                : ""}
            </Avatar>
          </Typography>
        </Grid>
        <Grid item={true} xs={9}>
          <Typography component="h6" color="inherit" className="dd-user-name">
            {loggedInUser.name}{" "}
            {loggedInUser.lastName ? loggedInUser.lastName : ""}
          </Typography>
          <Typography component="h6" color="inherit" className="dd-role-list">
            {loggedInUser.roleName ? loggedInUser.roleName : ""}
          </Typography>
        </Grid>
      </Grid>
      <Divider />
      <Grid
        container={true}
        direction="row"
        alignItems="center"
        className="dd-email-text-container"
      >
        <Grid item={true} xs={3}>
          <Typography component="div" className="text-center">
            <Typography component="span" className="dd-email-text">
              Email:
            </Typography>
          </Typography>
        </Grid>
        <Grid item={true} xs={9}>
          <Typography
            component="span"
            className="dd-email-text"
            title={`${loggedInUser.email}`}
          >{`${loggedInUser.email}`}</Typography>
        </Grid>
      </Grid>
      <Divider />
      <Grid container={true}>
        <Grid item={true} xs={12}>
          <Typography
            component="span"
            className="dd-logout-button"
            onClick={logoutUser}
            title={"logout"}
          >
            Logout
          </Typography>
        </Grid>
      </Grid>
    </Typography>
  );
}

export default UserDropdown;
