import { createSlice } from "@reduxjs/toolkit";

// Define Reducers
const initialState = {
  isUserDropDownShow: false,
};

const newHeader = createSlice({
  name: "newHeader",
  initialState,
  reducers: {
    setUserDropdownShow: (state: any, action: any) => {
      state.isUserDropDownShow = action.payload;
    },
  },
});

export const { setUserDropdownShow } = newHeader.actions;
export const newHeaderReducer = newHeader.reducer;
