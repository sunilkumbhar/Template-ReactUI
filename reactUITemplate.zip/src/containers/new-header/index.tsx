import React, { useState } from "react";
import Toolbar from "@material-ui/core/Toolbar";
import Grid from "@material-ui/core/Grid";
// import { Container } from "@material-ui/core";
import logo from "../../styles/images/uniceflogo2.png";
import Typography from "@material-ui/core/Typography";
import Button from "@material-ui/core/Button";
import AccountCircleOutlinedIcon from "@material-ui/icons/AccountCircleOutlined";
import OutsideAlerter from "./click-outside";
import Account from "./account";
import { HOME_PATH, ALL_REQUESTS, NEW_REQUEST } from "../../constants/api";
import { history } from "../../store/config";
import { useSelector } from "react-redux";

import { VerticalLine, UHeader, MenuContainer } from "./styles";
import "./index.css";

function NewHeader(props: any) {
  const [auth, setAuth] = useState(true);

  const router = useSelector((state: any) => state.router);
  const currentRoute = router.location.pathname;

  const loggedInUser = {
    name: "Ammar Tinwala",
    email: "atinwala@unicef.org",
    roleName: "Web Developer",
  };

  const goToPath = (path: any) => {
    history.push(path);
  };

  const logout = () => {
    localStorage.clear();
    setAuth(false);
    // Logout logic will go over here
  };

  const login = () => {
    setAuth(true);
    // Login logic will go over here
  };

  return (
    <React.Fragment>
      <UHeader position="relative">
        <Toolbar disableGutters={true}>
          <MenuContainer>
            <Grid
              container={true}
              direction="row"
              alignItems="center"
              justify="space-between"
            >
              <Grid item={true} xs={4}>
                <Grid
                  container={true}
                  spacing={1}
                  alignItems="center"
                  justify="flex-start"
                >
                  <Grid item={true}>
                    <Typography component="img" src={logo} alt="Unicef Logo" />
                  </Grid>
                  <Grid item={true}>
                    <VerticalLine />
                  </Grid>
                  <Grid item={true}>
                    <Typography
                      component="span"
                      color="inherit"
                      className="app-name"
                    >
                      CPH UI Template
                    </Typography>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item={true} xs={5}>
                <Grid
                  container={true}
                  spacing={3}
                  justify="center"
                  alignItems="center"
                >
                  <Grid item={true}>
                    <Typography
                      component="span"
                      className={
                        "menu-item" +
                        (currentRoute === HOME_PATH || currentRoute === "/"
                          ? " active-menu-item"
                          : "")
                      }
                      // @ts-ignore
                      onClick={() => goToPath(HOME_PATH)}
                    >
                      Home
                    </Typography>
                  </Grid>
                  <Grid item={true}>
                    <Typography
                      component="span"
                      className={
                        "menu-item" +
                        (currentRoute === ALL_REQUESTS
                          ? " active-menu-item"
                          : "")
                      }
                      // @ts-ignore
                      onClick={() => goToPath(ALL_REQUESTS)}
                    >
                      All Requests
                    </Typography>
                  </Grid>
                  <Grid item={true}>
                    <Typography
                      component="span"
                      className={
                        "menu-item" +
                        (currentRoute === NEW_REQUEST
                          ? " active-menu-item"
                          : "")
                      }
                      // @ts-ignore
                      onClick={() => goToPath(NEW_REQUEST)}
                    >
                      New Request
                    </Typography>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item={true} xs={3}>
                <Grid
                  container={true}
                  spacing={1}
                  alignItems="center"
                  justify="flex-end"
                >
                  <Grid item={true}>
                    {auth ? (
                      <OutsideAlerter>
                        <Account loggedInUser={loggedInUser} logout={logout} />
                      </OutsideAlerter>
                    ) : (
                      <Grid container={true} spacing={2} alignItems="center">
                        <Grid item={true}>
                          <Button
                            color="inherit"
                            onClick={login}
                            className="text-capitalize"
                          >
                            <AccountCircleOutlinedIcon className="marginR10" />
                            Login
                          </Button>
                        </Grid>
                      </Grid>
                    )}
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </MenuContainer>
        </Toolbar>
      </UHeader>
    </React.Fragment>
  );
}

export default NewHeader;
