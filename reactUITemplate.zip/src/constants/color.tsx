export const PRIMARY_COLOR: string = "#1CABE2";
export const SECONDARY_COLOR: string = "#FFFFFF";
export const PRIMARY_BUTTON_BG: string = "#0078D4";
export const PRIMARY_LABEL_COLOR: string = "#888888";
export const ERROR_COLOR: string = "#cc0000";
export const TOASTER_ERROR: string = "#d32f2f";
export const TOASTER_SUCCESS: string = "green";
export const SECONDARY_BUTTON_BG: string = "#f50057";
