export const AUTH_TOKEN: string = "CBE7AF75-1F7B-43E7-8734-C06166EDB5D2";
export const APP_NAME: string = "VFCalc";
export const BASE_PATH: string = "https://jsonplaceholder.typicode.com";

// ROUTES
export const NEW_REQUEST: string = "/new-request";
export const ALL_REQUESTS: string = "/all-request";
export const ABOUT_US: string = "/about-us";
export const HOME_PATH: string = "/";
