import styled from "styled-components";
import { InputLabel, FormControl } from "@material-ui/core";

export const FullWidthContainer = styled.div`
  width: 100%;
`;

export const PageWrapper = styled.div`
  padding: 10px;
  position: relative;
  margin-left: auto;
  margin-right: auto;

  @media (min-width: 1024px) {
    max-width: 960px;
  }

  @media (min-width: 1440px) {
    max-width: 1200px;
  }
`;

export const FormWrapper = styled(PageWrapper)``;

export const FormToolbar = styled.div`
  padding: 10px 0;
`;

export const StyledInputLabel = styled(InputLabel)`
  && {
    .req-label {
      color: #f44336;
    }
  }
`;

export const StyledFormControl = styled(FormControl)`
  && {
    width: 100%;
    display: block;
    position: relative;
  }
`;

export const StyledAutoSelectInputLabel = styled(InputLabel)`
  && {
    position: relative;
    .req-label {
      color: #f44336;
    }
    transform: translate(0, 1.5px) scale(0.75);
    transform-origin: top left;
  }
`;
