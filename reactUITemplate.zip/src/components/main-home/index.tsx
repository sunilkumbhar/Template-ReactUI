import React from "react";
import { Switch, Route } from "react-router-dom";
import { NEW_REQUEST, HOME_PATH, ALL_REQUESTS } from "../../constants/api";
import NewRequestComponent from "../../containers/new-request";
// import Header from "../../containers/header";
import AboutUs from "../../containers/about-us";
import AllRequestsComponent from "../../containers/all-requests";
import NewHeader from "../../containers/new-header";

function MainHomeComponent(props: any) {
  return (
    <>
      <NewHeader />
      <Switch>
        <Route
          exact={true}
          path={NEW_REQUEST}
          component={NewRequestComponent}
        />
        <Route
          exact={true}
          path={ALL_REQUESTS}
          component={AllRequestsComponent}
        />
        <Route exact={true} path={HOME_PATH} component={AboutUs} />
      </Switch>
    </>
  );
}

export default MainHomeComponent;
