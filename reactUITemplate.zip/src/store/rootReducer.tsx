import { connectRouter } from "connected-react-router";
import { combineReducers } from "redux";
import { commonReducer } from "./common/slice";
import { allRequestsReducer } from "../containers/all-requests/slice";
import { newHeaderReducer } from "../containers/new-header/slice";

export default (history: any) =>
  combineReducers({
    router: connectRouter(history),
    common: commonReducer,
    allRequests: allRequestsReducer,
    newHeader: newHeaderReducer,
    // rest of your reducers
  });
