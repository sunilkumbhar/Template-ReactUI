import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  pageTitle: "",
};

const commonSlice = createSlice({
  name: "common",
  initialState,
  reducers: {
    setPageTitle: (state: any, action: any) => {
      state.pageTitle = action.payload;
    },
  },
});

export const { setPageTitle } = commonSlice.actions;
export const commonReducer = commonSlice.reducer;
