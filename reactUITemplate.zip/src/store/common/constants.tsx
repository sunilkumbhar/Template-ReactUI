export const ActionTypes = {
  COMMON_SET_PAGE_TITLE: "COMMON_SET_PAGE_TITLE",
};
